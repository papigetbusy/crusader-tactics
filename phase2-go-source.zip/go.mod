module crusadertactics/wasmtest

go 1.24
